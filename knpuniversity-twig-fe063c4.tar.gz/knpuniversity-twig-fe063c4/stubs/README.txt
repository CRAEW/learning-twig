Stubs!
======

If you're coding along with the tutorial, this directory contains some files
that will help you at certain spots when we paste in some code:

* layout.twig: The original layout.twig file that we create
* stubs.php:   A collection of several small PHP snippets
